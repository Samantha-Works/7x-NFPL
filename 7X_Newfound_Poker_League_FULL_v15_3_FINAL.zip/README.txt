7X Newfound Poker League FULL v15.2 FINAL

Final hero tightening update:
- full banner visible
- centered correctly
- no cropped logo
- no oversized menu overlay
- tighter hero spacing
- preserved ALL app logic/features

Built from the full v15 foundation.
